# Title     : Twitter API Scraping
# Objective : To Scrap Twitter with API

# Step 1: Install and load rtweet package 

install.packages("rtweet")
library(rtweet)

install.packages("devtools")
library(devtools)
install_github("mkearney/rtweet")

# Step 2: API Authorization 

# With access token / secret
token <- create_token(
  consumer_key = "iQTTyUbAyHgmVSroI6ZzdDhTE",
  consumer_secret = "EdNcnVTZOvkYfMCOdzN49fcnai89pXtl9W4CbvGuU6IJpvqtrA",
  access_token = "835382250-eQTjby83AASZsYapwp2h59wRjv7VwiEhYWUBP0vE",
  access_secret = "4Q6487247T0CtZ2xxrPNLu228E1fyMe8rfMV9CfBdB1Ew")

# Step 3: Crawling Data Twitter 

#  Twitter username 
my_username='my_enjune'

# Mencari 1000 tweets dengan keyword: "djarum"
tweet <- search_tweets(q = "djarum", n = 10000)

# Nama kolom tweet dan dimensi
colnames(tweet)
dim(tweet)

# melihat 7 kolom
k <- tweet[,c("created_at", "screen_name", "text", "favorite_count",
              "reply_count", "retweet_count", "quote_count"
              )]

head(k)

#melihat jenis data k
str(k)

#melihat summary k
summary(k)

#membersihkan data

library(dplyr)
a = k %>%
  select(text,
         retweet_count) %>%
  arrange( desc(retweet_count))  %>% 
  filter(retweet_count >= 0)

a


b = a[!duplicated(a[,c("text")]),]
b

#membuat csv file dari data twitter web scrapping 10000 data tentang djarum
write.csv(b, file = "C:/Users/ide2/Documents/ANGGUN_MBA/webscraping/twitter_web_scrapping.csv",row.names=FALSE)

